#!/bin/bash

httpd -D FOREGROUND
